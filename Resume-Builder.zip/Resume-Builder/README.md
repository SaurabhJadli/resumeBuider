<!-- PROJECT BANNER -->
<h1 align="center">📄 AI-Powered Resume Builder</h1>
<p align="center">
  Build stunning, professional resumes in minutes — powered by React, Tailwind, Lucide Icons, and PrebuiltUI.
  <br />
  <a href="https://resume-builder-sage-theta.vercel.app/"><strong>🚀 Live Demo on Vercel »</strong></a>
  <br /><br />
</p>

<p align="center">
  <img src="https://img.shields.io/badge/React-18.0-blue?logo=react" />
  <img src="https://img.shields.io/badge/TailwindCSS-3.0-38BDF8?logo=tailwindcss" />
  <img src="https://img.shields.io/badge/Lucide-Icons-orange?logo=lucide" />
  <img src="https://img.shields.io/badge/PrebuiltUI-Components-purple" />
  <img src="https://img.shields.io/badge/Deployed-Vercel-black?logo=vercel" />
</p>

---

## 🌐 **Live Project**
🔗 **Demo:** https://resume-builder-sage-theta.vercel.app/  
🔗 **GitHub Repository:** https://github.com/AfsarWebDev/resume-builder

---

## ⭐ **Project Preview**

### 🖥️ Homepage Preview  
<p align="center">
  <img src="./src/assets/preview.png" width="800" alt="Resume Builder Homepage" />
</p>

---

## 🎯 **About the Project**

The **AI-Powered Resume Builder** helps users generate modern, professional resumes in minutes.  
Built using **React + Tailwind + PrebuiltUI**, it provides:

- ⚡ Fast and easy resume creation  
- 🎨 Multiple template styles  
- 🎯 Live preview as you type  
- 📥 PDF-ready output  
- 🔧 Fully customizable sections  
- 🧩 Modular components for scalability  

---

## 🔥 **Features**

### ✏️ Resume Sections  
- Personal Information  
- Education  
- Work Experience  
- Projects  
- Skills  
- Summary  

### 🎨 Templates & Customization  
- Minimal, Classic, and Modern templates  
- Accent color selection  
- Real-time preview  
- Lucide icons integration  

### 🧠 UI & Experience  
- Smooth UX using **PrebuiltUI**  
- Fully responsive  
- Clean dashboard  
- File upload support  
- Modal-based interactions  

---

## 🛠️ **Tech Stack**

| Category    | Technology           |
|-------------|----------------------|
| Frontend    | React (Vite)         |
| UI Framework| Tailwind CSS         |
| UI Components| PrebuiltUI          |
| Icons       | Lucide React Icons   |
| Routing     | React Router         |
| Hosting     | Vercel               |

---

## 📦 Installation & Running Locally

```bash
git clone https://github.com/AfsarWebDev/resume-builder.git
cd resume-builder
npm install
npm run dev